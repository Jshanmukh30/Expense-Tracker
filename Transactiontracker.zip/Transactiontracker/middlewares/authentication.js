const { validateToken } = require("../services/authentication");

const checkForAuthenticationCookie = (cookieName) => {
    return (req, res, next) => {
        const tokenCookieValue = req.cookies[cookieName];
        if (!tokenCookieValue) {
            
            return next();
        }
        try {
            const userPayload = validateToken(tokenCookieValue);
            req.user = userPayload;
        } catch (error) {
            // Optionally, handle the error (e.g., log it)
        }
        return next();
    };
};

module.exports = {checkForAuthenticationCookie}