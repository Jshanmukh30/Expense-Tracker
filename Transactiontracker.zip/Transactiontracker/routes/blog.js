const {Router} = require('express');
const router = Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const Blog = require('../models/blog');
const Comment = require('../models/comment');

const storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, path.resolve(`./public/uploads/`))
    },
    filename: function(req, file, cb) {
       const fileName = `${Date.now()}-${file.originalname}`;
       cb(null, fileName);
    },
});

const upload = multer({storage: storage});

router.get('/add-new', (req, res) => {
    return res.render('addBlog', {
        user: req.user,
    });
});

router.get("/:id", async (req, res) => {
    try {
        const blog = await Blog.findById(req.params.id).populate("createdBy");
        if (!blog) {
            return res.status(404).render('404', {
                user: req.user,
                message: 'Blog not found'
            });
        }
        const comments = await Comment.find({blogId: req.params.id}).populate('createdBy');
        return res.render("blog", {
            user: req.user,
            blog,
            comments,
        });
    } catch (error) {
        console.error('Error fetching blog:', error);
        return res.status(500).render('error', {
            user: req.user,
            message: 'Error loading blog'
        });
    }
});

router.post("/comment/:blogId", async (req, res) => {
    try {
        await Comment.create({
            content: req.body.content,
            blogId: req.params.blogId,
            createdBy: req.user._id,
        });
        return res.redirect(`/blog/${req.params.blogId}`);
    } catch (error) {
        console.error('Error creating comment:', error);
        return res.redirect(`/blog/${req.params.blogId}`);
    }
});

router.post("/", upload.single("coverImage"), async (req, res) => {
    try {
        const {title, body} = req.body;
        const blog = await Blog.create({
            body,
            title,
            createdBy: req.user._id,
            coverImageURL: `/uploads/${req.file.filename}`,
            creditordebit: req.body.creditordebit,
            amount: req.body.amount,
            category: req.body.category,
        });
        return res.redirect(`/blog/${blog._id}`);
    } catch (error) {
        console.error('Error creating blog:', error);
        return res.redirect('/blog/add-new');
    }
});

router.post("/:id/amount", async (req, res) => {
    try {
        const { amount } = req.body;
        await Blog.findByIdAndUpdate(req.params.id, { amount });
        res.redirect(`/blog/${req.params.id}`);
    } catch (error) {
        console.error('Error updating amount:', error);
        res.redirect(`/blog/${req.params.id}`);
    }
});

// DELETE route to delete a blog
router.delete("/:id", async (req, res) => {
    try {
        const blogId = req.params.id;
        
        // Find the blog first to get the image path
        const blog = await Blog.findById(blogId);
        
        if (!blog) {
            return res.status(404).json({ error: 'Blog not found' });
        }
        
        // Check if the current user is the owner of the blog
        if (blog.createdBy.toString() !== req.user._id.toString()) {
            return res.status(403).json({ error: 'You are not authorized to delete this blog' });
        }
        
        // Delete associated comments first
        await Comment.deleteMany({ blogId: blogId });
        
        // Delete the cover image file if it exists
        if (blog.coverImageURL) {
            const imagePath = path.join(__dirname, '../public', blog.coverImageURL);
            try {
                if (fs.existsSync(imagePath)) {
                    fs.unlinkSync(imagePath);
                    console.log('Cover image deleted successfully');
                }
            } catch (fileError) {
                console.error('Error deleting cover image:', fileError);
                // Continue with blog deletion even if image deletion fails
            }
        }
        
        // Delete the blog from database
        await Blog.findByIdAndDelete(blogId);
        
        // Redirect to home page with success message
        res.redirect('/?deleted=true');
        
    } catch (error) {
        console.error('Error deleting blog:', error);
        res.status(500).json({ error: 'Error deleting blog' });
    }
});

module.exports = router;